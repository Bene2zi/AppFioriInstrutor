sap.ui.define([
	"AppFioriAluno99/appfiorialuno99/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
